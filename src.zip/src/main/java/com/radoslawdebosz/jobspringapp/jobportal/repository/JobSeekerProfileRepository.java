package com.radoslawdebosz.jobspringapp.jobportal.repository;

import com.radoslawdebosz.jobspringapp.jobportal.entity.JobSeekerProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobSeekerProfileRepository extends JpaRepository<JobSeekerProfile, Integer> {
}
